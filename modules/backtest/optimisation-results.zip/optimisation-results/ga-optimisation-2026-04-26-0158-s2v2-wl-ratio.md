# Genetic Algorithm Run: s2v2-wl-ratio

**Started at:** 2026-04-26T00:58:17.673487Z
**Target:** Composite(NonEmptyList(LinesCrossing(HLC3,JMA(43,-67,1),JMA(16,35,8)), ThresholdCrossing(Close,RSX(16),51.0,44.0), VolatilityRegimeDetection(6,SMA(4))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`
* #2: 2.95655 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,51,2),JMA(8,-65,3)), ThresholdCrossing(Close,RSX(5),57.0,36.0), VolatilityRegimeDetection(21,SMA(10))),Any)`
* #3: 2.91014 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,51,2),JMA(8,-65,3)), ThresholdCrossing(Close,RSX(5),57.0,36.0), VolatilityRegimeDetection(21,SMA(10))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`
* #2: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`
* #3: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 3.357935 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),62.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`
* #2: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`
* #3: 3.289475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),64.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 3.568845 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,18,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #2: 3.431035 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,20,5)), ThresholdCrossing(Close,RSX(12),60.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.357935 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(34,-78,2),JMA(5,50,3)), ThresholdCrossing(Close,RSX(5),62.0,29.0), VolatilityRegimeDetection(39,SMA(5))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 3.59223 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,20,5)), ThresholdCrossing(Close,RSX(12),57.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #2: 3.568845 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,18,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.568845 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,18,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 3.59223 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,20,5)), ThresholdCrossing(Close,RSX(12),57.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #2: 3.568845 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,18,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.568845 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,18,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 3.67647 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #2: 3.59223 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,20,5)), ThresholdCrossing(Close,RSX(12),57.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.58846 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(6,35,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 3.67647 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #2: 3.67647 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.67647 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.72569 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(26,SMA(11))),Any)`
* #3: 3.67647 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.72569 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(26,SMA(11))),Any)`
* #3: 3.67885 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,48,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.73495 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.72569 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(26,SMA(11))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.73495 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`
* #3: 3.72569 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(26,SMA(11))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.74372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,23,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.73495 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),59.0,45.0), VolatilityRegimeDetection(30,SMA(11))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,15,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,15,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,20,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.75372 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,-60,1),JMA(8,15,5)), ThresholdCrossing(Close,RSX(12),58.0,45.0), VolatilityRegimeDetection(32,SMA(11))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,38,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,16,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 3.964855 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.815165 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,16,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(33,SMA(5))),Any)`
* #3: 3.773195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),59.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #2: 3.964855 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.964855 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,15,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #3: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,29,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #3: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`

## Final Results

**Top 25 members:**

* #1: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #2: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,29,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #3: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #4: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,29,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #5: 4.0 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(7,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #6: 3.97849 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,1),JMA(10,31,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(31,SMA(5))),Any)`
* #7: 3.32501 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,-6,1),JMA(7,26,10)), ThresholdCrossing(Close,RSX(10),57.0,41.0), VolatilityRegimeDetection(27,SMA(5))),Any)`
* #8: 3.210875 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(26,22,1),JMA(7,19,9)), ThresholdCrossing(Close,RSX(8),61.0,41.0), VolatilityRegimeDetection(32,SMA(5))),Any)`
* #9: 3.208995 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(29,-4,1),JMA(7,40,9)), ThresholdCrossing(Close,RSX(13),56.0,43.0), VolatilityRegimeDetection(20,SMA(33))),Any)`
* #10: 3.20118 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(33,-4,3),JMA(9,8,9)), ThresholdCrossing(Close,RSX(10),50.0,33.0), VolatilityRegimeDetection(41,SMA(22))),Any)`
* #11: 3.157105 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,9,1),JMA(5,45,10)), ThresholdCrossing(Close,RSX(12),54.0,37.0), VolatilityRegimeDetection(31,SMA(22))),Any)`
* #12: 3.13158 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,5,2),JMA(7,27,10)), ThresholdCrossing(Close,RSX(14),50.0,34.0), VolatilityRegimeDetection(24,SMA(20))),Any)`
* #13: 3.110805 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(31,31,1),JMA(8,44,9)), ThresholdCrossing(Close,RSX(11),57.0,38.0), VolatilityRegimeDetection(26,SMA(5))),Any)`
* #14: 3.10484 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,8,3),JMA(7,28,10)), ThresholdCrossing(Close,RSX(10),55.0,41.0), VolatilityRegimeDetection(23,SMA(5))),Any)`
* #15: 3.054195 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,-14,1),JMA(7,-7,10)), ThresholdCrossing(Close,RSX(9),54.0,36.0), VolatilityRegimeDetection(26,SMA(13))),Any)`
* #16: 3.03701 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,-4,1),JMA(9,37,10)), ThresholdCrossing(Close,RSX(13),63.0,45.0), VolatilityRegimeDetection(30,SMA(24))),Any)`
* #17: 3.008615 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(28,29,3),JMA(11,-12,8)), ThresholdCrossing(Close,RSX(15),51.0,37.0), VolatilityRegimeDetection(25,SMA(12))),Any)`
* #18: 3.007935 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(25,2,1),JMA(12,45,9)), ThresholdCrossing(Close,RSX(14),56.0,36.0), VolatilityRegimeDetection(35,SMA(38))),Any)`
* #19: 3.006435 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(32,14,1),JMA(8,22,8)), ThresholdCrossing(Close,RSX(12),59.0,38.0), VolatilityRegimeDetection(33,SMA(47))),Any)`
* #20: 2.95611 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(28,-4,2),JMA(10,30,10)), ThresholdCrossing(Close,RSX(28),54.0,41.0), VolatilityRegimeDetection(41,SMA(52))),Any)`
* #21: 2.92485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,-19,1),JMA(8,61,10)), ThresholdCrossing(Close,RSX(10),63.0,43.0), VolatilityRegimeDetection(28,SMA(10))),Any)`
* #22: 2.909565 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(22,5,2),JMA(9,42,10)), ThresholdCrossing(Close,RSX(9),50.0,34.0), VolatilityRegimeDetection(26,SMA(12))),Any)`
* #23: 2.873245 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(33,3,5),JMA(10,-5,10)), ThresholdCrossing(Close,RSX(10),50.0,35.0), VolatilityRegimeDetection(30,SMA(42))),Any)`
* #24: 2.872555 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,20,1),JMA(7,13,5)), ThresholdCrossing(Close,RSX(13),60.0,44.0), VolatilityRegimeDetection(27,SMA(5))),Any)`
* #25: 2.86485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(29,16,2),JMA(10,23,9)), ThresholdCrossing(Close,RSX(15),59.0,34.0), VolatilityRegimeDetection(35,SMA(28))),Any)`

**Stats:**
Stats: Best=4.0, Avg=2.0831269921874997, Worst=0.0

**Duration:**

Total duration: 3755222 milliseconds
