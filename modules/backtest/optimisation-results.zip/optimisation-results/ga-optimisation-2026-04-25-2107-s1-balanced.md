# Genetic Algorithm Run: s1-balanced

**Started at:** 2026-04-25T20:07:03.668183Z
**Target:** Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(14),83.0,23.0), ValueTracking(Momentum,Close,STOCH(14)), VolatilityRegimeDetection(10,SMA(20))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 0.4600795 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(27)), VolatilityRegimeDetection(8,SMA(10))),Any)`
* #2: 0.43507075 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(26)), ThresholdCrossing(Close,STOCH(19),88.0,21.0), ValueTracking(Momentum,Close,STOCH(18)), VolatilityRegimeDetection(7,SMA(7))),Any)`
* #3: 0.42441825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(30)), ThresholdCrossing(Close,STOCH(17),86.0,18.0), ValueTracking(Momentum,Close,STOCH(17)), VolatilityRegimeDetection(40,SMA(5))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 0.4600795 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(27)), VolatilityRegimeDetection(8,SMA(10))),Any)`
* #2: 0.4600795 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(27)), VolatilityRegimeDetection(8,SMA(10))),Any)`
* #3: 0.4600795 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(27)), VolatilityRegimeDetection(8,SMA(10))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 0.46233725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(28)), VolatilityRegimeDetection(7,SMA(10))),Any)`
* #2: 0.46233725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(28)), VolatilityRegimeDetection(7,SMA(10))),Any)`
* #3: 0.4600795 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,20.0), ValueTracking(Momentum,Close,STOCH(27)), VolatilityRegimeDetection(8,SMA(10))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 0.46814675 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(28)), VolatilityRegimeDetection(7,SMA(10))),Any)`
* #2: 0.4674085 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(7,SMA(12))),Any)`
* #3: 0.4674085 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(7,SMA(12))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 0.46814675 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(28)), VolatilityRegimeDetection(7,SMA(10))),Any)`
* #2: 0.4674085 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(7,SMA(12))),Any)`
* #3: 0.4674085 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(7,SMA(12))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.475656 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(7,SMA(12))),Any)`
* #3: 0.475656 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(7,SMA(12))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.475656 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(7,SMA(12))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47865975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`
* #3: 0.47878825 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(25)), ThresholdCrossing(Close,STOCH(16),85.0,20.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(6,SMA(12))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.4829625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),85.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.48657475 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(8,SMA(11))),Any)`
* #3: 0.48657475 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(8,SMA(11))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #2: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.48657475 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(8,SMA(11))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 0.49057225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(8,SMA(11))),Any)`
* #2: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`

## Final Results

**Top 25 members:**

* #1: 0.49057225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(30)), VolatilityRegimeDetection(8,SMA(11))),Any)`
* #2: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #3: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #4: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #5: 0.487784 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #6: 0.48657475 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(8,SMA(11))),Any)`
* #7: 0.48633 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),86.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(11))),Any)`
* #8: 0.4482755 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(27)), ThresholdCrossing(Close,STOCH(17),87.0,11.0), ValueTracking(Momentum,Close,STOCH(32)), VolatilityRegimeDetection(10,SMA(5))),Any)`
* #9: 0.44285225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),84.0,21.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(8,SMA(17))),Any)`
* #10: 0.42817525 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(19),86.0,25.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(25,SMA(5))),Any)`
* #11: 0.42623025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(30)), ThresholdCrossing(Close,STOCH(21),87.0,20.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(5,SMA(12))),Any)`
* #12: 0.4246 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(18),86.0,16.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(9,SMA(14))),Any)`
* #13: 0.4242065 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),83.0,17.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(5,SMA(16))),Any)`
* #14: 0.42046425 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(24)), ThresholdCrossing(Close,STOCH(12),81.0,25.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(5,SMA(10))),Any)`
* #15: 0.4189155 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(30)), ThresholdCrossing(Close,STOCH(18),86.0,19.0), ValueTracking(Momentum,Close,STOCH(29)), VolatilityRegimeDetection(12,SMA(11))),Any)`
* #16: 0.4144785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(31)), ThresholdCrossing(Close,STOCH(17),86.0,23.0), ValueTracking(Momentum,Close,STOCH(39)), VolatilityRegimeDetection(10,SMA(11))),Any)`
* #17: 0.413767 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(16),87.0,14.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(7,SMA(5))),Any)`
* #18: 0.41334675 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(19),86.0,20.0), ValueTracking(Momentum,Close,STOCH(45)), VolatilityRegimeDetection(15,SMA(11))),Any)`
* #19: 0.406907 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(13),86.0,21.0), ValueTracking(Momentum,Close,STOCH(36)), VolatilityRegimeDetection(8,SMA(9))),Any)`
* #20: 0.400858 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(30)), ThresholdCrossing(Close,STOCH(18),89.0,21.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(5,SMA(18))),Any)`
* #21: 0.4006485 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(26)), ThresholdCrossing(Close,STOCH(21),83.0,23.0), ValueTracking(Momentum,Close,STOCH(34)), VolatilityRegimeDetection(9,SMA(17))),Any)`
* #22: 0.400588 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(29)), ThresholdCrossing(Close,STOCH(17),80.0,27.0), ValueTracking(Momentum,Close,STOCH(31)), VolatilityRegimeDetection(8,SMA(15))),Any)`
* #23: 0.40012275 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(17),92.0,20.0), ValueTracking(Momentum,Close,STOCH(33)), VolatilityRegimeDetection(7,SMA(9))),Any)`
* #24: 0.39904675 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(30)), ThresholdCrossing(Close,STOCH(22),86.0,18.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(9,SMA(13))),Any)`
* #25: 0.39794175 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,HMA(28)), ThresholdCrossing(Close,STOCH(20),82.0,21.0), ValueTracking(Momentum,Close,STOCH(35)), VolatilityRegimeDetection(5,SMA(23))),Any)`

**Stats:**
Stats: Best=0.49057225, Avg=0.3162212207031249, Worst=0.097787

**Duration:**

Total duration: 13698561 milliseconds
