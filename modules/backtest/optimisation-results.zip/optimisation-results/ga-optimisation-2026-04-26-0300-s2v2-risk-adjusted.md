# Genetic Algorithm Run: s2v2-risk-adjusted

**Started at:** 2026-04-26T02:00:52.917673Z
**Target:** Composite(NonEmptyList(LinesCrossing(HLC3,JMA(43,-67,1),JMA(16,35,8)), ThresholdCrossing(Close,RSX(16),51.0,44.0), VolatilityRegimeDetection(6,SMA(4))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 45.94186639469658 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(23),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 40.86901392505378 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,67,3),JMA(27,-5,3)), ThresholdCrossing(Close,RSX(17),75.0,29.0), VolatilityRegimeDetection(23,SMA(31))),Any)`
* #3: 37.149032746136385 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(16,75,2),JMA(25,32,3)), ThresholdCrossing(Close,RSX(15),74.0,25.0), VolatilityRegimeDetection(47,SMA(31))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 53.7673541543901 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 46.47244094488189 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,7,2)), ThresholdCrossing(Close,RSX(23),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 45.94186639469658 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(23),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 53.7673541543901 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 53.012139068945196 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(23),67.0,21.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.41909251620507 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,3,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 56.8164997053624 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,23,3),JMA(22,8,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 56.8164997053624 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,23,3),JMA(22,8,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.8164997053624 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,23,3),JMA(22,8,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 56.8164997053624 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,23,3),JMA(22,8,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.60294637595757 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,15,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 56.8164997053624 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,23,3),JMA(22,8,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.73435474366529 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,24.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 57.764761343547434 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,23.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`

## Final Results

**Top 25 members:**

* #1: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #2: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #3: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #4: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #5: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #6: 61.63517998468215 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #7: 47.45804347826087 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,17,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(14),73.0,27.0), VolatilityRegimeDetection(17,SMA(40))),Any)`
* #8: 45.56528810408922 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,7,3),JMA(22,4,2)), ThresholdCrossing(Close,RSX(20),73.0,27.0), VolatilityRegimeDetection(17,SMA(28))),Any)`
* #9: 44.44589833920483 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,26,3),JMA(20,-18,2)), ThresholdCrossing(Close,RSX(28),78.0,31.0), VolatilityRegimeDetection(13,SMA(32))),Any)`
* #10: 37.91106906338695 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,17,3),JMA(22,10,2)), ThresholdCrossing(Close,RSX(20),72.0,29.0), VolatilityRegimeDetection(16,SMA(63))),Any)`
* #11: 35.87757551510302 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,50,4),JMA(22,-43,2)), ThresholdCrossing(Close,RSX(20),69.0,29.0), VolatilityRegimeDetection(28,SMA(35))),Any)`
* #12: 32.39608574091333 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(27,38,5),JMA(24,-15,2)), ThresholdCrossing(Close,RSX(18),73.0,26.0), VolatilityRegimeDetection(20,SMA(40))),Any)`
* #13: 31.762015431811843 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(33,45,8),JMA(20,5,1)), ThresholdCrossing(Close,RSX(20),67.0,24.0), VolatilityRegimeDetection(22,SMA(41))),Any)`
* #14: 29.175875305339073 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(26,44,3),JMA(22,21,2)), ThresholdCrossing(Close,RSX(20),72.0,24.0), VolatilityRegimeDetection(20,SMA(35))),Any)`
* #15: 28.942226228030645 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,96,5),JMA(29,28,2)), ThresholdCrossing(Close,RSX(21),70.0,26.0), VolatilityRegimeDetection(17,SMA(39))),Any)`
* #16: 28.70350955131053 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-1,3),JMA(27,-18,3)), ThresholdCrossing(Close,RSX(27),76.0,27.0), VolatilityRegimeDetection(21,SMA(39))),Any)`
* #17: 28.613045218087233 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,55,2),JMA(26,46,2)), ThresholdCrossing(Close,RSX(15),73.0,17.0), VolatilityRegimeDetection(20,SMA(35))),Any)`
* #18: 27.308697037273017 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(26,37,5),JMA(32,8,2)), ThresholdCrossing(Close,RSX(19),74.0,33.0), VolatilityRegimeDetection(18,SMA(41))),Any)`
* #19: 27.153131029643923 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(15,55,2),JMA(34,13,3)), ThresholdCrossing(Close,RSX(21),81.0,38.0), VolatilityRegimeDetection(25,SMA(37))),Any)`
* #20: 25.921345315419522 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(25,46,5),JMA(22,20,2)), ThresholdCrossing(Close,RSX(20),72.0,11.0), VolatilityRegimeDetection(18,SMA(18))),Any)`
* #21: 25.085049672885873 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(22,1,3),JMA(19,-2,2)), ThresholdCrossing(Close,RSX(29),74.0,31.0), VolatilityRegimeDetection(18,SMA(32))),Any)`
* #22: 23.5350052246604 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(25,11,3),JMA(28,11,2)), ThresholdCrossing(Close,RSX(26),77.0,36.0), VolatilityRegimeDetection(20,SMA(33))),Any)`
* #23: 23.226881102814474 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(16,1,5),JMA(22,79,1)), ThresholdCrossing(Close,RSX(22),72.0,32.0), VolatilityRegimeDetection(15,SMA(44))),Any)`
* #24: 23.048324045579307 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,-6,4),JMA(31,-2,2)), ThresholdCrossing(Close,RSX(21),74.0,37.0), VolatilityRegimeDetection(12,SMA(35))),Any)`
* #25: 20.536058619359814 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,-9,3),JMA(18,20,1)), ThresholdCrossing(Close,RSX(23),76.0,34.0), VolatilityRegimeDetection(27,SMA(36))),Any)`

**Stats:**
Stats: Best=61.63517998468215, Avg=6.350064787001519, Worst=-13.751143920444147

**Duration:**

Total duration: 3768238 milliseconds
