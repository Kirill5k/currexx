# Genetic Algorithm Run: s2-balanced

**Started at:** 2026-04-25T23:55:22.273667Z
**Target:** Composite(NonEmptyList(LinesCrossing(HLC3,JMA(43,-67,1),JMA(16,45,8)), ThresholdCrossing(Close,RSX(16),50.0,44.0), VolatilityRegimeDetection(9,SMA(5))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 0.48842625 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,17,4),JMA(5,13,2)), ThresholdCrossing(Close,RSX(5),76.0,22.0), VolatilityRegimeDetection(30,SMA(43))),Any)`
* #2: 0.48459925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(16,31,3),JMA(14,6,3)), ThresholdCrossing(Close,RSX(25),75.0,27.0), VolatilityRegimeDetection(27,SMA(53))),Any)`
* #3: 0.4821275 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(12,10,2),JMA(13,-1,4)), ThresholdCrossing(Close,RSX(31),64.0,14.0), VolatilityRegimeDetection(28,SMA(42))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 0.55627 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(17,-4,4),JMA(5,32,2)), ThresholdCrossing(Close,RSX(5),69.0,31.0), VolatilityRegimeDetection(35,SMA(43))),Any)`
* #2: 0.5312585 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,-4,4),JMA(5,32,2)), ThresholdCrossing(Close,RSX(5),76.0,22.0), VolatilityRegimeDetection(35,SMA(43))),Any)`
* #3: 0.51212225 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(17,-7,3),JMA(8,-60,3)), ThresholdCrossing(Close,RSX(26),73.0,30.0), VolatilityRegimeDetection(31,SMA(48))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 0.5607075 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(17,-4,4),JMA(5,32,2)), ThresholdCrossing(Close,RSX(5),69.0,31.0), VolatilityRegimeDetection(35,SMA(48))),Any)`
* #2: 0.55627 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(17,-4,4),JMA(5,32,2)), ThresholdCrossing(Close,RSX(5),69.0,31.0), VolatilityRegimeDetection(35,SMA(43))),Any)`
* #3: 0.5554875 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(17,-4,4),JMA(5,24,2)), ThresholdCrossing(Close,RSX(5),69.0,31.0), VolatilityRegimeDetection(35,SMA(43))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 0.5733055 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(30,2,4),JMA(5,36,5)), ThresholdCrossing(Close,RSX(9),69.0,31.0), VolatilityRegimeDetection(34,SMA(56))),Any)`
* #2: 0.5730755 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-28,3),JMA(6,10,2)), ThresholdCrossing(Close,RSX(11),70.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.5730755 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-28,3),JMA(6,10,2)), ThresholdCrossing(Close,RSX(11),70.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 0.586539 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-39,3),JMA(6,-29,2)), ThresholdCrossing(Close,RSX(11),66.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.580862 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-39,3),JMA(6,10,2)), ThresholdCrossing(Close,RSX(11),66.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.580862 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-39,3),JMA(6,10,2)), ThresholdCrossing(Close,RSX(11),66.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.619806 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(18,22,3),JMA(6,-4,2)), ThresholdCrossing(Close,RSX(16),71.0,31.0), VolatilityRegimeDetection(33,SMA(60))),Any)`
* #3: 0.586539 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(19,-39,3),JMA(6,-29,2)), ThresholdCrossing(Close,RSX(11),66.0,21.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 0.6487345 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 0.6487345 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.635438 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-82,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6487345 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6386425 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(8,-98,3)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6487345 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),66.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 0.650928 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,29.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 0.650928 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,29.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 0.6536485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-6,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.650928 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,29.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6505925 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 0.6536485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-6,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6536485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-6,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.650928 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-5,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,29.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 0.655762 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-52,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.6536485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-6,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.6536485 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-6,4),JMA(10,-82,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.656198 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-7,4),JMA(10,-80,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.655762 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-52,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.656198 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-7,4),JMA(10,-80,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.655762 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-52,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.656198 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-7,4),JMA(10,-80,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.656198 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-7,4),JMA(10,-80,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.656198 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-7,4),JMA(10,-80,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`

## Final Results

**Top 25 members:**

* #1: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #2: 0.658342 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #3: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #4: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #5: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #6: 0.65651 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #7: 0.64462 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,23.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #8: 0.612361 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(54))),Any)`
* #9: 0.602442 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-2,4),JMA(10,-55,4)), ThresholdCrossing(Close,RSX(13),67.0,28.0), VolatilityRegimeDetection(33,SMA(52))),Any)`
* #10: 0.5913205 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(28,9,4),JMA(9,-54,10)), ThresholdCrossing(Close,RSX(11),65.0,31.0), VolatilityRegimeDetection(30,SMA(61))),Any)`
* #11: 0.58395375 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(20),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #12: 0.5731115 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,-2,4),JMA(10,-8,4)), ThresholdCrossing(Close,RSX(18),67.0,28.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #13: 0.5694785 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(28,1,4),JMA(9,-73,4)), ThresholdCrossing(Close,RSX(10),67.0,28.0), VolatilityRegimeDetection(28,SMA(60))),Any)`
* #14: 0.5672915 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(27,-27,4),JMA(6,-39,10)), ThresholdCrossing(Close,RSX(14),68.0,29.0), VolatilityRegimeDetection(32,SMA(56))),Any)`
* #15: 0.55850325 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(20,-28,4),JMA(28,-49,7)), ThresholdCrossing(Close,RSX(15),67.0,22.0), VolatilityRegimeDetection(29,SMA(58))),Any)`
* #16: 0.5569255 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(26,-7,5),JMA(18,-58,6)), ThresholdCrossing(Close,RSX(16),67.0,29.0), VolatilityRegimeDetection(38,SMA(54))),Any)`
* #17: 0.5540475 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(24,24,3),JMA(11,-71,10)), ThresholdCrossing(Close,RSX(16),68.0,31.0), VolatilityRegimeDetection(31,SMA(58))),Any)`
* #18: 0.542157 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-14,4),JMA(11,-56,4)), ThresholdCrossing(Close,RSX(13),69.0,31.0), VolatilityRegimeDetection(34,SMA(56))),Any)`
* #19: 0.54213 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(29,1,4),JMA(10,-39,5)), ThresholdCrossing(Close,RSX(10),66.0,25.0), VolatilityRegimeDetection(39,SMA(44))),Any)`
* #20: 0.541555 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-20,4),JMA(17,-63,9)), ThresholdCrossing(Close,RSX(17),73.0,39.0), VolatilityRegimeDetection(39,SMA(51))),Any)`
* #21: 0.5274725 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,5,3),JMA(6,-51,4)), ThresholdCrossing(Close,RSX(11),68.0,29.0), VolatilityRegimeDetection(37,SMA(54))),Any)`
* #22: 0.527433 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(18,-2,4),JMA(10,-58,4)), ThresholdCrossing(Close,RSX(13),67.0,19.0), VolatilityRegimeDetection(33,SMA(55))),Any)`
* #23: 0.5222095 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(23,7,4),JMA(13,-52,5)), ThresholdCrossing(Close,RSX(6),63.0,21.0), VolatilityRegimeDetection(28,SMA(46))),Any)`
* #24: 0.5194335 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(21,-16,4),JMA(6,-38,4)), ThresholdCrossing(Close,RSX(13),68.0,28.0), VolatilityRegimeDetection(36,SMA(58))),Any)`
* #25: 0.518086 - `Composite(NonEmptyList(LinesCrossing(HLC3,JMA(22,-2,3),JMA(14,-17,4)), ThresholdCrossing(Close,RSX(13),67.0,30.0), VolatilityRegimeDetection(33,SMA(52))),Any)`

**Stats:**
Stats: Best=0.658342, Avg=0.36715574267578166, Worst=0.0

**Duration:**

Total duration: 3775377 milliseconds
