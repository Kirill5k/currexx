# Genetic Algorithm Run: s4-profit

**Started at:** 2026-04-26T04:06:56.565161Z
**Target:** Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(50,0,2)), KeltnerChannel(Close,EMA(20),20,1.5), ThresholdCrossing(Close,RSX(14),85.0,15.0), VolatilityRegimeDetection(14,SMA(20))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 0.34107 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,7,3)), KeltnerChannel(Close,EMA(32),19,1.1), ThresholdCrossing(Close,RSX(29),77.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.32868 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,7,3)), KeltnerChannel(Close,EMA(32),19,1.1), ThresholdCrossing(Close,RSX(29),79.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.32657 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(33,7,3)), KeltnerChannel(Close,EMA(32),24,1.1), ThresholdCrossing(Close,RSX(30),79.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 0.35917 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-23,3)), KeltnerChannel(Close,EMA(22),19,1.1), ThresholdCrossing(Close,RSX(29),77.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.34897 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,7,3)), KeltnerChannel(Close,EMA(32),23,1.1), ThresholdCrossing(Close,RSX(30),79.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.34667 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-23,3)), KeltnerChannel(Close,EMA(22),23,1.1), ThresholdCrossing(Close,RSX(29),77.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 0.35917 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-23,3)), KeltnerChannel(Close,EMA(22),19,1.1), ThresholdCrossing(Close,RSX(29),77.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.35917 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-23,3)), KeltnerChannel(Close,EMA(22),19,1.1), ThresholdCrossing(Close,RSX(29),77.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.35917 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-23,3)), KeltnerChannel(Close,EMA(22),19,1.1), ThresholdCrossing(Close,RSX(29),77.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 0.36468 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,7,3)), KeltnerChannel(Close,EMA(32),15,1.1), ThresholdCrossing(Close,RSX(30),72.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.36468 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,7,3)), KeltnerChannel(Close,EMA(32),15,1.1), ThresholdCrossing(Close,RSX(30),72.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.36242 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-29,3)), KeltnerChannel(Close,EMA(22),19,1.1), ThresholdCrossing(Close,RSX(29),78.0,6.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 0.39079 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-28,3)), KeltnerChannel(Close,EMA(26),15,1.1), ThresholdCrossing(Close,RSX(29),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.38448 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-29,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(29),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.38448 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-29,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(29),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 0.40277 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-54,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.39079 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-28,3)), KeltnerChannel(Close,EMA(26),15,1.1), ThresholdCrossing(Close,RSX(29),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.39079 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-28,3)), KeltnerChannel(Close,EMA(26),15,1.1), ThresholdCrossing(Close,RSX(29),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 0.40836 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-85,3)), KeltnerChannel(Close,EMA(26),15,1.1), ThresholdCrossing(Close,RSX(23),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.40277 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-54,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.40277 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-54,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 0.44095 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(24),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.41768 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-78,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.41768 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-78,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.44095 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(24),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.41768 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-78,3)), KeltnerChannel(Close,EMA(26),19,1.1), ThresholdCrossing(Close,RSX(25),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 0.45612 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),46,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 0.45612 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),46,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 0.45612 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),46,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.45108 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),36,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 0.46395 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(21),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.45928 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),39,1.0), ThresholdCrossing(Close,RSX(22),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.45612 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),46,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 0.46395 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(21),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46395 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(21),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.45928 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),39,1.0), ThresholdCrossing(Close,RSX(22),78.0,5.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46458 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-92,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(19),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46458 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-92,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(19),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,13.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`

## Final Results

**Top 25 members:**

* #1: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #2: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #3: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #4: 0.47013 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #5: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #6: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #7: 0.46708 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #8: 0.42323 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),49,1.0), ThresholdCrossing(Close,RSX(17),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #9: 0.41824 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(29),50,1.0), ThresholdCrossing(Close,RSX(22),78.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #10: 0.40982 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(24),49,1.0), ThresholdCrossing(Close,RSX(22),76.0,12.0), VolatilityRegimeDetection(37,SMA(30))),Any)`
* #11: 0.35334 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-88,3)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(22),84.0,12.0), VolatilityRegimeDetection(29,SMA(30))),Any)`
* #12: 0.34327 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-74,3)), KeltnerChannel(Close,EMA(22),50,1.0), ThresholdCrossing(Close,RSX(21),80.0,23.0), VolatilityRegimeDetection(38,SMA(30))),Any)`
* #13: 0.30987 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-59,3)), KeltnerChannel(Close,EMA(42),48,1.0), ThresholdCrossing(Close,RSX(35),72.0,23.0), VolatilityRegimeDetection(47,SMA(32))),Any)`
* #14: 0.30837 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(34,-88,3)), KeltnerChannel(Close,EMA(50),46,1.0), ThresholdCrossing(Close,RSX(26),77.0,9.0), VolatilityRegimeDetection(37,SMA(26))),Any)`
* #15: 0.30188 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-78,3)), KeltnerChannel(Close,EMA(31),47,1.0), ThresholdCrossing(Close,RSX(12),80.0,17.0), VolatilityRegimeDetection(36,SMA(57))),Any)`
* #16: 0.29434 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(37,-23,3)), KeltnerChannel(Close,EMA(42),50,0.9), ThresholdCrossing(Close,RSX(19),75.0,21.0), VolatilityRegimeDetection(46,SMA(37))),Any)`
* #17: 0.28505 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(38,-37,3)), KeltnerChannel(Close,EMA(38),50,1.1), ThresholdCrossing(Close,RSX(28),82.0,9.0), VolatilityRegimeDetection(39,SMA(32))),Any)`
* #18: 0.28022 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(33,-62,3)), KeltnerChannel(Close,EMA(37),50,1.0), ThresholdCrossing(Close,RSX(23),85.0,6.0), VolatilityRegimeDetection(38,SMA(31))),Any)`
* #19: 0.27674 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(33,-80,3)), KeltnerChannel(Close,EMA(35),50,1.3), ThresholdCrossing(Close,RSX(21),82.0,15.0), VolatilityRegimeDetection(36,SMA(42))),Any)`
* #20: 0.2737 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-56,3)), KeltnerChannel(Close,EMA(33),48,1.0), ThresholdCrossing(Close,RSX(15),83.0,20.0), VolatilityRegimeDetection(44,SMA(27))),Any)`
* #21: 0.26532 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(36,-16,4)), KeltnerChannel(Close,EMA(26),50,1.0), ThresholdCrossing(Close,RSX(28),70.0,24.0), VolatilityRegimeDetection(40,SMA(30))),Any)`
* #22: 0.26242 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(41,-86,3)), KeltnerChannel(Close,EMA(27),49,1.1), ThresholdCrossing(Close,RSX(24),83.0,23.0), VolatilityRegimeDetection(40,SMA(35))),Any)`
* #23: 0.26063 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(32,-75,3)), KeltnerChannel(Close,EMA(36),48,1.0), ThresholdCrossing(Close,RSX(21),79.0,18.0), VolatilityRegimeDetection(25,SMA(39))),Any)`
* #24: 0.25955 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-59,3)), KeltnerChannel(Close,EMA(32),36,1.0), ThresholdCrossing(Close,RSX(25),79.0,17.0), VolatilityRegimeDetection(36,SMA(41))),Any)`
* #25: 0.24209 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-59,3)), KeltnerChannel(Close,EMA(34),44,1.1), ThresholdCrossing(Close,RSX(22),79.0,32.0), VolatilityRegimeDetection(35,SMA(36))),Any)`

**Stats:**
Stats: Best=0.47013, Avg=0.11173355468749994, Worst=-0.13599

**Duration:**

Total duration: 4808100 milliseconds
