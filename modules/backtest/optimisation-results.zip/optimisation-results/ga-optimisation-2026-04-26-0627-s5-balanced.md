# Genetic Algorithm Run: s5-balanced

**Started at:** 2026-04-26T05:27:04.688594Z
**Target:** Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(50,0,2)), BollingerBands(Close,SMA(20),20,2.0), VolatilityRegimeDetection(14,SMA(20)), ThresholdCrossing(Close,RSX(14),80.0,20.0), ValueTracking(Momentum,Close,RSX(14))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 0.45773766666666665 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(35,28,1)), BollingerBands(Close,SMA(31),31,2.1), VolatilityRegimeDetection(6,SMA(36)), ThresholdCrossing(Close,RSX(18),58.0,35.0), ValueTracking(Momentum,Close,RSX(48))),Any)`
* #2: 0.4459315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(27,-61,2)), BollingerBands(Close,SMA(32),32,2.1), VolatilityRegimeDetection(19,SMA(19)), ThresholdCrossing(Close,RSX(8),66.0,29.0), ValueTracking(Momentum,Close,RSX(13))),Any)`
* #3: 0.4428565 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(35,70,1)), BollingerBands(Close,SMA(31),31,2.1), VolatilityRegimeDetection(6,SMA(36)), ThresholdCrossing(Close,RSX(18),58.0,35.0), ValueTracking(Momentum,Close,RSX(48))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 0.4904755 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(27,-61,1)), BollingerBands(Close,SMA(34),32,2.1), VolatilityRegimeDetection(19,SMA(19)), ThresholdCrossing(Close,RSX(8),66.0,29.0), ValueTracking(Momentum,Close,RSX(13))),Any)`
* #2: 0.46034216666666666 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(35,14,1)), BollingerBands(Close,SMA(29),32,2.0), VolatilityRegimeDetection(21,SMA(20)), ThresholdCrossing(Close,RSX(7),76.0,29.0), ValueTracking(Momentum,Close,RSX(26))),Any)`
* #3: 0.45773766666666665 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(35,28,1)), BollingerBands(Close,SMA(31),31,2.1), VolatilityRegimeDetection(6,SMA(36)), ThresholdCrossing(Close,RSX(18),58.0,35.0), ValueTracking(Momentum,Close,RSX(48))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 0.5175905 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-71,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),74.0,33.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5163245 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-51,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),67.0,33.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.4904755 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(27,-61,1)), BollingerBands(Close,SMA(34),32,2.1), VolatilityRegimeDetection(19,SMA(19)), ThresholdCrossing(Close,RSX(8),66.0,29.0), ValueTracking(Momentum,Close,RSX(13))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 0.5261235 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-81,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5175905 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-71,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),74.0,33.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5163985 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-100,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),74.0,31.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 0.5261235 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-81,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5261235 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-81,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5192545 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-95,1)), BollingerBands(Close,SMA(23),35,1.9), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),74.0,31.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 0.5400345 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.534692 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(13)), ThresholdCrossing(Close,RSX(6),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5287768333333334 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(29,-75,1)), BollingerBands(Close,SMA(23),35,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),72.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 0.5400345 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.534692 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(13)), ThresholdCrossing(Close,RSX(6),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.534479 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(31,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(25,SMA(19)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5400345 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5400345 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5418695 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9), VolatilityRegimeDetection(20,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5400345 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-85,1)), BollingerBands(Close,SMA(23),34,1.9000000000000001), VolatilityRegimeDetection(20,SMA(18)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 0.5458225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-100,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 0.5482785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5458225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-100,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.545368 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-97,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 0.5482785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5482785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5458225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(30,-100,1)), BollingerBands(Close,SMA(26),34,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 0.5515185 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(6),71.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #2: 0.5482785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
* #3: 0.5482785 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,JMA(28,-100,1)), BollingerBands(Close,SMA(26),33,1.9000000000000001), VolatilityRegimeDetection(21,SMA(17)), ThresholdCrossing(Close,RSX(5),69.0,30.0), ValueTracking(Momentum,Close,RSX(19))),Any)`
