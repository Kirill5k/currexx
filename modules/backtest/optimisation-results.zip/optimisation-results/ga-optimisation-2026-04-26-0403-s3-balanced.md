# Genetic Algorithm Run: s3-balanced

**Started at:** 2026-04-26T03:03:41.178272Z
**Target:** Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.3,0.4)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.4,0.05)), ThresholdCrossing(Close,RSX(14),85.0,15.0), VolatilityRegimeDetection(14,SMA(20))),Any)
**Parameters:** GA(250,350,0.7,0.2,0.025,true)

## Progress

### Generation 10 out of 350

**Top Members:**

* #1: 0.17138 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(26),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.166724 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.5,0.02)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.5,0.02)), ThresholdCrossing(Close,RSX(14),76.0,41.0), VolatilityRegimeDetection(13,SMA(28))),Any)`
* #3: 0.16649725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(16),67.0,23.0), VolatilityRegimeDetection(12,SMA(31))),Any)`

### Generation 20 out of 350

**Top Members:**

* #1: 0.1752315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17138 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(26),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.170391 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(16),66.0,14.0), VolatilityRegimeDetection(12,SMA(31))),Any)`

### Generation 30 out of 350

**Top Members:**

* #1: 0.1758525 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.23,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.4,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1752315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1752315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 40 out of 350

**Top Members:**

* #1: 0.1758525 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.23,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.4,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1752315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1752315 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.28,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 50 out of 350

**Top Members:**

* #1: 0.17942175 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17942175 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.17942175 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 60 out of 350

**Top Members:**

* #1: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17953375 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,18.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.17942175 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 70 out of 350

**Top Members:**

* #1: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.17953375 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,18.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 80 out of 350

**Top Members:**

* #1: 0.18006975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,23.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 90 out of 350

**Top Members:**

* #1: 0.18006975 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,23.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.17959025 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,24.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 100 out of 350

**Top Members:**

* #1: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1821095 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,25.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.180403 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.5,0.02)), ThresholdCrossing(Close,RSX(23),67.0,38.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 110 out of 350

**Top Members:**

* #1: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1821095 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,25.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 120 out of 350

**Top Members:**

* #1: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 130 out of 350

**Top Members:**

* #1: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.18289325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,40.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 140 out of 350

**Top Members:**

* #1: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.187894 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),66.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.187096 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(23),67.0,39.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 150 out of 350

**Top Members:**

* #1: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 160 out of 350

**Top Members:**

* #1: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 170 out of 350

**Top Members:**

* #1: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 180 out of 350

**Top Members:**

* #1: 0.18970125 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.18970125 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1879325 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(15),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 190 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.190641 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),64.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.18970125 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 200 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.190641 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),64.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.18970125 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 210 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.190641 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),64.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.18970125 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,41.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 220 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.19129875 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(8),67.0,34.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.19129875 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(8),67.0,34.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 230 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.19129875 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(8),67.0,34.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 240 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 250 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 260 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 270 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 280 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 290 out of 350

**Top Members:**

* #1: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 300 out of 350

**Top Members:**

* #1: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1927365 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.16,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 310 out of 350

**Top Members:**

* #1: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.1927365 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.16,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1915285 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(12),67.0,31.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 320 out of 350

**Top Members:**

* #1: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.1927365 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.16,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 330 out of 350

**Top Members:**

* #1: 0.19427725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 340 out of 350

**Top Members:**

* #1: 0.19427725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

### Generation 350 out of 350

**Top Members:**

* #1: 0.19427725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`

## Final Results

**Top 25 members:**

* #1: 0.19427725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #2: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #3: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #4: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #5: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #6: 0.193992 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #7: 0.18136 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),67.0,22.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #8: 0.17427625 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.15)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.02)), ThresholdCrossing(Close,RSX(10),70.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #9: 0.1717415 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.34,0.01)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.47,0.02)), ThresholdCrossing(Close,RSX(5),63.0,29.0), VolatilityRegimeDetection(11,SMA(31))),Any)`
* #10: 0.16617275 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.03)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.02)), ThresholdCrossing(Close,RSX(10),69.0,31.0), VolatilityRegimeDetection(14,SMA(27))),Any)`
* #11: 0.153271 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.09)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.5,0.01)), ThresholdCrossing(Close,RSX(5),74.0,52.0), VolatilityRegimeDetection(9,SMA(36))),Any)`
* #12: 0.1506885 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.04)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.44,0.02)), ThresholdCrossing(Close,RSX(8),82.0,15.0), VolatilityRegimeDetection(16,SMA(27))),Any)`
* #13: 0.1503555 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.02)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(14),73.0,37.0), VolatilityRegimeDetection(25,SMA(27))),Any)`
* #14: 0.1489045 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.27,0.08)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(12),67.0,42.0), VolatilityRegimeDetection(23,SMA(38))),Any)`
* #15: 0.14707725 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.24,0.06)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.4,0.01)), ThresholdCrossing(Close,RSX(6),66.0,36.0), VolatilityRegimeDetection(12,SMA(21))),Any)`
* #16: 0.14525225 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.03)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(12),63.0,29.0), VolatilityRegimeDetection(16,SMA(34))),Any)`
* #17: 0.1435485 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.12)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(7),62.0,32.0), VolatilityRegimeDetection(10,SMA(25))),Any)`
* #18: 0.143229 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.31,0.12)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(14),66.0,34.0), VolatilityRegimeDetection(33,SMA(45))),Any)`
* #19: 0.1414305 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.09)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(19),73.0,14.0), VolatilityRegimeDetection(11,SMA(32))),Any)`
* #20: 0.140613 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.06)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(12),73.0,37.0), VolatilityRegimeDetection(16,SMA(27))),Any)`
* #21: 0.13932666666666668 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.2,0.12)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.03)), ThresholdCrossing(Close,RSX(11),72.0,33.0), VolatilityRegimeDetection(9,SMA(35))),Any)`
* #22: 0.1391255 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.12)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.01)), ThresholdCrossing(Close,RSX(9),71.0,30.0), VolatilityRegimeDetection(16,SMA(47))),Any)`
* #23: 0.138957 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.25,0.16)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.48,0.01)), ThresholdCrossing(Close,RSX(16),71.0,34.0), VolatilityRegimeDetection(17,SMA(28))),Any)`
* #24: 0.138712 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.22,0.13)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.42,0.01)), ThresholdCrossing(Close,RSX(12),59.0,25.0), VolatilityRegimeDetection(11,SMA(36))),Any)`
* #25: 0.13844875 - `Composite(NonEmptyList(TrendChangeDetection(HLC3,Kalman(0.35000000000000003,0.09)), ValueTracking(Velocity,HLC3,KalmanVelocity(0.45,0.02)), ThresholdCrossing(Close,RSX(19),73.0,30.0), VolatilityRegimeDetection(13,SMA(28))),Any)`

**Stats:**
Stats: Best=0.19427725, Avg=0.0896281396484375, Worst=0.0

**Duration:**

Total duration: 3795366 milliseconds
